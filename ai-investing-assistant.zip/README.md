# AI Investing Assistant

An AI-powered web app for investing insights, tips, and stock news.